startup_command = "\rRUN DL1:TET\r"

co = coroutine.create(function ()
  natkeyboard = manager.machine.natkeyboard

  one_moment = emu.attotime.from_double(0.02)

  key_right = manager.machine.ioport.ports[":ie15:keyboard:TERM_LINE1"].fields["Right"]
  key_next_setup = manager.machine.ioport.ports[":ie15:keyboard:TERM_LINE3"].fields["Next SetUp"]
  key_setup = manager.machine.ioport.ports[":ie15:keyboard:TERM_LINEC"].fields["SetUp"]

  type_key = function(key)
    key:set_value(1)
    natkeyboard:post_coded("")
    emu.wait(one_moment)
    key:set_value(0)
    natkeyboard:post_coded("")
    emu.wait(one_moment)
  end

  type_key(key_setup)
  type_key(key_right)
  type_key(key_right)
  type_key(key_right)
  type_key(key_right)
  type_key(key_right)
  type_key(key_right)
  type_key(key_next_setup)
  type_key(key_right)
  type_key(key_next_setup)
  type_key(key_setup)

  natkeyboard:post_coded(startup_command)

end)

coroutine.resume(co)